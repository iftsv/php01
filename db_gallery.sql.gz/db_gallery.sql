-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2018 at 09:39 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_gallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `gallery_file`
--

CREATE TABLE `gallery_file` (
  `id_file` int(11) NOT NULL,
  `name_original` varchar(255) DEFAULT NULL,
  `name_translit` varchar(255) DEFAULT NULL,
  `path_original` text,
  `path_preview` text,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gallery_file`
--

INSERT INTO `gallery_file` (`id_file`, `name_original`, `name_translit`, `path_original`, `path_preview`, `size`) VALUES
(12, 'Ð¥Ñ€Ð¸Ð·Ð°Ð½Ñ‚ÐµÐ¼Ð°.jpg', 'khrizantema.jpg', 'img_original/khrizantema.jpg', 'img_thumbs/khrizantema.jpg', 879394),
(13, 'Koala.jpg', 'koala.jpg', 'img_original/koala.jpg', 'img_thumbs/koala.jpg', 780831),
(14, 'Lighthouse.jpg', 'lighthouse.jpg', 'img_original/lighthouse.jpg', 'img_thumbs/lighthouse.jpg', 561276),
(15, 'Penguins.jpg', 'penguins.jpg', 'img_original/penguins.jpg', 'img_thumbs/penguins.jpg', 777835);

-- --------------------------------------------------------

--
-- Table structure for table `gallery_stats`
--

CREATE TABLE `gallery_stats` (
  `id_file` int(11) NOT NULL DEFAULT '0',
  `view_counter` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `gallery_stats`
--

INSERT INTO `gallery_stats` (`id_file`, `view_counter`) VALUES
(12, 8),
(13, 8),
(14, 2),
(15, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gallery_file`
--
ALTER TABLE `gallery_file`
  ADD PRIMARY KEY (`id_file`);

--
-- Indexes for table `gallery_stats`
--
ALTER TABLE `gallery_stats`
  ADD PRIMARY KEY (`id_file`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gallery_file`
--
ALTER TABLE `gallery_file`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
