-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 08, 2018 at 10:52 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laptopsheaven_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id_feedback` int(11) NOT NULL,
  `author_name` varchar(255) DEFAULT NULL,
  `author_email` varchar(255) DEFAULT NULL,
  `author_message` text,
  `feedback_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id_feedback`, `author_name`, `author_email`, `author_message`, `feedback_datetime`) VALUES
(1, 'ivan', 'ivan@gg.ru', 'test', '2018-09-08 10:27:42'),
(2, 'ivan', 'ivan@gg.ru', 'test', '2018-09-08 10:29:02'),
(3, 'Олег', 'oleg@oleg.ru', 'Привет! Проверка сохранения сообщения', '2018-09-08 10:41:10'),
(4, 'Петр', 'peter@peter.ru', 'Привет! Сообщения сохраняются', '2018-09-08 10:47:31'),
(5, 'Vasiliy', 'vasiliya@gggg.ru', 'Надо добавить капчу', '2018-09-08 10:48:21');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id_item` int(11) NOT NULL,
  `item_name` text NOT NULL,
  `id_img_item` int(11) NOT NULL,
  `desc_short` text NOT NULL,
  `desc_full` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `item_img`
--

CREATE TABLE `item_img` (
  `id_img_item` int(11) NOT NULL,
  `path_full` text NOT NULL,
  `path_min` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `item_spec`
--

CREATE TABLE `item_spec` (
  `id_spec` int(11) NOT NULL,
  `spec_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `item_spec_link`
--

CREATE TABLE `item_spec_link` (
  `id_spec_link` int(11) NOT NULL,
  `id_spec` int(11) NOT NULL,
  `id_item` int(11) NOT NULL,
  `item_spec_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id_feedback`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id_item`);

--
-- Indexes for table `item_img`
--
ALTER TABLE `item_img`
  ADD PRIMARY KEY (`id_img_item`);

--
-- Indexes for table `item_spec`
--
ALTER TABLE `item_spec`
  ADD PRIMARY KEY (`id_spec`);

--
-- Indexes for table `item_spec_link`
--
ALTER TABLE `item_spec_link`
  ADD PRIMARY KEY (`id_spec_link`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id_feedback` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `item_img`
--
ALTER TABLE `item_img`
  MODIFY `id_img_item` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `item_spec`
--
ALTER TABLE `item_spec`
  MODIFY `id_spec` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `item_spec_link`
--
ALTER TABLE `item_spec_link`
  MODIFY `id_spec_link` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
